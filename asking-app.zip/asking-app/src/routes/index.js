import React from 'react';
import { Switch } from 'react-router-dom';
import Route from './Route';

import Main from '~/pages/Main';
import Asking from '~/pages/Asking';
import Login from '~/pages/SignIn';
import Register from '~/pages/SignUp';

import Dashboard from '~/pages/Dashboard';
import Profile from '~/pages/Profile';
import Users from '~/pages/Users';
import Questions from '~/pages/Questions';
import Theme from '~/pages/Theme';

export default function Routes() {
  return (
    <Switch>
      <Route path="/" exact component={Main} />
      <Route path="/duvida" component={Asking} />
      <Route path="/login" component={Login} />
      <Route path="/register" component={Register} />

      <Route path="/dashboard" component={Dashboard} isPrivate />
      <Route path="/profile" component={Profile} isPrivate />
      <Route path="/users" component={Users} isPrivate />
      <Route
        path="/questions/theme/:theme_id"
        component={Questions}
        isPrivate
      />
      <Route path="/theme" component={Theme} isPrivate />

      <Route path="/" component={() => <h1>404</h1>} />
    </Switch>
  );
}
