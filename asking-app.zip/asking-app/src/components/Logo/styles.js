import styled from 'styled-components';

export const Container = styled.div`
  display: flex;
  flex-direction: row;

  img {
    width: 50px;
  }

  aside {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: center;
    margin-left: 10px;

    p {
      color: #c2bbbb;
      font-size: 20px;
    }
  }
`;
