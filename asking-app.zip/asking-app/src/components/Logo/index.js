import React from 'react';

import logo from '~/assets/logo.svg';
import { Container } from './styles';

export default function Logo() {
  return (
    <Container>
      <img src={logo} alt="Minha Pergunta" />
      <aside>
        <p>Minha</p>
        <p>Pergunta</p>
      </aside>
    </Container>
  );
}
