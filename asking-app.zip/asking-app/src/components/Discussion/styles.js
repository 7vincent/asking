import styled from 'styled-components';
import banner from '~/assets/banner.jpg';

export const Content = styled.div`
  height: 100%;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
`;

export const Header = styled.div`
  height: 250px;
  background-image: url(${banner});
  background-repeat: no-repeat;
  background-position: top;
  background-size: cover;
  background-size: 100% 280px;
`;

export const Container = styled.div`
  width: 100%;
  margin: 0 auto;

  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  color: #c2bbbb;

  h1 {
    font-size: calc(1.8em + 1vw);
    text-align: center;
  }
`;

export const Footer = styled.div`
  width: 100%;
  max-width: 800px;
  margin: 20px auto;
  color: #c2bbbb;

  aside {
    width: 100%;
    display: flex;
    justify-content: space-between;
    align-items: center;

    h2 {
      font-size: 20px;
    }
  }
`;
