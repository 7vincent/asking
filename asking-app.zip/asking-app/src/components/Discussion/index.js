import React, { useEffect, useState } from 'react';

import api from '~/services/api';

import { Content, Container, Header, Footer } from './styles';

import Logo from '~/components/Logo';

export default function Discussion() {
  const [question, setQuestion] = useState([]);

  useEffect(() => {
    async function loadQuestion() {
      await api.get(`question-discussion`).then(response => {
        setQuestion(response.data);
      });
    }

    loadQuestion();
    const interval = setInterval(() => {
      loadQuestion();
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <Content>
      <Header />
      <Container>
        <h1>
          {(question && question.ask) ||
            'Não tenha dúvidas, acesse http://localhost:3333/duvida'}
        </h1>
      </Container>
      <Footer>
        <aside>
          <Logo />
          <h2>
            {question && ((question.theme && question.theme.speaker) || '')}
          </h2>
        </aside>
      </Footer>
    </Content>
  );
}
