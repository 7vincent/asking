import produce from 'immer';

const INITIAL_STATE = {
  approvedAsk: null,
};

export default function ask(state = INITIAL_STATE, action) {
  return produce(state, draft => {
    switch (action.type) {
      case '@ask/APPROVED_ASK_SUCCESS': {
        draft.approvedAsk = action.payload.ask;
        break;
      }
      case '@ask/MARK_ASK_DISCUSSED_SUCCESS': {
        draft.approvedAsk = null;
        break;
      }
      case '@ask/APPROVED_ASK_REQUEST_SUCCESS': {
        draft.approvedAsk = action.payload.ask;
        break;
      }
      default:
    }
  });
}
