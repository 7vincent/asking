import { takeLatest, call, put, all } from 'redux-saga/effects';
import { toast } from 'react-toastify';

import api from '~/services/api';

import {
  approvedAskSuccess,
  markAskDiscussedSuccess,
  approvedAskRequestSuccess,
} from './actions';

export function* approvedAsk({ payload }) {
  try {
    const { id, name, email, question } = payload.data;

    const ask = {
      name,
      email,
      question,
    };

    const response = yield call(api.put, `questions/${id}`, ask);

    toast.success('Pergunta aprovada com sucesso!');

    yield put(approvedAskSuccess(response.data));
  } catch (err) {
    toast.error('Já possui uma pergunta aprovada aguardando discussão.');
  }
}

export function* markAskDiscussed({ payload }) {
  try {
    const { id, name, email, question } = payload.data;

    const ask = {
      name,
      email,
      question,
    };

    const response = yield call(api.put, `questions/${id}`, ask);

    toast.success('Discussão finalizada!');

    yield put(markAskDiscussedSuccess(response.data));
  } catch (err) {
    toast.error('Pergunta já discutida.');
  }
}

export function* requestApprovedAsk() {
  try {
    const response = yield call(api.get, 'discussion');
    yield put(approvedAskRequestSuccess(response.data));
  } catch (err) {
    toast.error('Ocorreu um erro');
  }
}

export default all([
  takeLatest('@ask/APPROVED_ASK_SUCCESS', approvedAsk),
  takeLatest('@ask/MARK_ASK_DISCUSSED_SUCCESS', markAskDiscussed),
  takeLatest('@ask/APPROVED_ASK_REQUEST', requestApprovedAsk),
]);
