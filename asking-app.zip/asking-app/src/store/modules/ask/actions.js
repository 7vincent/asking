export function markAskDiscussedSuccess(ask) {
  return {
    type: '@ask/MARK_ASK_DISCUSSED_SUCCESS',
    payload: { ask },
  };
}

export function approvedAskSuccess(ask) {
  return {
    type: '@ask/APPROVED_ASK_SUCCESS',
    payload: { ask },
  };
}

export function approvedAskRequest() {
  return {
    type: '@ask/APPROVED_ASK_REQUEST',
  };
}

export function approvedAskRequestSuccess(ask) {
  return {
    type: '@ask/APPROVED_ASK_REQUEST_SUCCESS',
    payload: { ask },
  };
}
