import { takeLatest, call, put, all } from 'redux-saga/effects';
import { toast } from 'react-toastify';

import api from '~/services/api';

import { themeRequestSuccess } from './actions';

export function* requestTheme() {
  try {
    const response = yield call(api.get, 'themes/?currentDiscussion=true');

    yield put(themeRequestSuccess(response.data));
  } catch (err) {
    toast.error('Nenhum tema cadastrado');
  }
}

export default all([takeLatest('@theme/THEME_REQUEST', requestTheme)]);
