import produce from 'immer';

const INITIAL_STATE = {
  loading: false,
  theme: null,
};

export default function auth(state = INITIAL_STATE, action) {
  return produce(state, draft => {
    switch (action.type) {
      case '@theme/THEME_REQUEST': {
        draft.loading = true;
        break;
      }
      case '@theme/THEME_REQUEST_SUCCESS': {
        draft.theme = action.payload.theme;
        draft.loading = false;
        break;
      }
      default:
    }
  });
}
