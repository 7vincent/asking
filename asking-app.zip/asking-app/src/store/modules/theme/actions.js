export function themeRequest() {
  return {
    type: '@theme/THEME_REQUEST',
  };
}

export function themeRequestSuccess(theme) {
  return {
    type: '@theme/THEME_REQUEST_SUCCESS',
    payload: { theme },
  };
}
