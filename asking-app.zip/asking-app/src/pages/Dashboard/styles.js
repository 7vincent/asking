import styled from 'styled-components';

export const Container = styled.div`
  max-width: 600px;
  margin: 50px auto;
  display: flex;
  flex-direction: column;

  button {
    border: 0;
  }

  header {
    display: flex;
    align-self: center;
    align-items: center;

    button {
      border: 0;
      background: none;
    }

    strong {
      color: #fff;
      font-size: 24px;
      margin: 0 15px;
    }
  }

  a {
    background: #fff;
    border-radius: 5px;
    color: #333;
    margin: 10px;

    display: flex;
    flex-direction: column;
    align-items: center;

    strong {
      font-size: 20px;
      padding: 5px;
    }

    span {
      font-size: 14px;
      padding-bottom: 5px;
    }

    &:hover {
      opacity: 0.8;
    }
  }

  > a {
    display: flex;
    align-items: center;
    align-self: center;
    background: #fff;
    width: 6%;
    border-radius: 50%;
  }
`;
