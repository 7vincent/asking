import React, { useState, useMemo, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { format, subDays, addDays } from 'date-fns';
import pt from 'date-fns/locale/pt';
import { MdChevronLeft, MdChevronRight, MdAddCircle } from 'react-icons/md';
import { useSelector } from 'react-redux';
import api from '~/services/api';

import { Container } from './styles';

export default function Dashboard() {
  const [date, setDate] = useState(new Date());
  const [schedule, setSchedule] = useState([]);
  const token = useSelector(state => state.auth.token);

  const dateFormatted = useMemo(
    () => format(date, "d 'de' MMMM", { locale: pt }),
    [date]
  );

  useEffect(() => {
    async function loadSchedule() {
      api.defaults.headers.Authorization = `Bearer ${token}`;
      const response = await api.get('schedule', {
        params: { date },
      });
      setSchedule(response.data);
    }
    loadSchedule();
  }, [date, token]);

  function handlePrevDay() {
    setDate(subDays(date, 1));
  }

  function handleNextDay() {
    setDate(addDays(date, 1));
  }

  return (
    <Container>
      <header>
        <button type="button" onClick={handlePrevDay}>
          <MdChevronLeft size={36} color="#fff" />
        </button>
        <strong>{dateFormatted}</strong>
        <button type="button" onClick={handleNextDay}>
          <MdChevronRight size={36} color="#fff" />
        </button>
      </header>
      <ul>
        {schedule.map(event => (
          <li key={event.id}>
            <Link to={`/questions/theme/${event.id}`}>
              <strong>{event.description}</strong>
              <span>{event.speaker}</span>
            </Link>
          </li>
        ))}
      </ul>
      <Link to={`/theme/?date=${format(date, 'MM-dd-yyyy')}`}>
        <MdAddCircle size={36} color="#312438" />
      </Link>
    </Container>
  );
}
