import React from 'react';

import Discussion from '~/components/Discussion';

// import { Container } from './styles';

export default function Main() {
  return (
    <>
      <Discussion />
    </>
  );
}
