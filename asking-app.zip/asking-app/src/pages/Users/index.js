import React from 'react';

// import { Container } from './styles';

export default function Users() {
  return <h1>Users</h1>;
}
