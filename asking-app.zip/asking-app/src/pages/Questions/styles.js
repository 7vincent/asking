import styled from 'styled-components';

export const Container = styled.div`
  max-width: 600px;
  margin: 50px auto;
  display: flex;
  flex-direction: column;
  background: #fff;
  border-radius: 7px;
  padding: 20px;
  max-height: 400px;
  overflow: auto;

  display: flex;
  flex-direction: row;
  justify-content: space-between;

  button {
    border: none;
    background: none;
    display: flex;
  }

  ul {
    width: 100%;

    li {
      border-bottom: 1px solid #999;
      padding: 10px 0;

      display: flex;
      flex-direction: row;
      justify-content: space-between;
      align-items: center;

      aside {
        p {
          font-size: 14px;
          &:last-child {
            font-size: 9px;
          }
        }
      }

      div {
        display: flex;

        button {
          margin-left: 15px;
        }
      }

      &:last-child {
        border-bottom: none;
      }
    }
  }
`;
