import React, { useState, useEffect, useCallback } from 'react';
import { FaRegPlayCircle, FaRegStopCircle } from 'react-icons/fa';
import { MdStopScreenShare, MdScreenShare, MdArchive } from 'react-icons/md';
import { toast } from 'react-toastify';

import api from '~/services/api';

import { Container } from './styles';

export default function Questions({ match }) {
  const { theme_id } = match.params;
  const [theme, setTheme] = useState([]);
  // const [theme, setTheme] = useState([]);

  const fetchRequest = useCallback(() => {
    async function loadQuestions() {
      const response = await api.get(`unarquived-questions/theme/${theme_id}`);
      await setTheme(response.data);
    }

    loadQuestions();
  }, [theme_id]);

  useEffect(() => {
    fetchRequest();

    const interval = setInterval(() => {
      fetchRequest();
    }, 5000);
    return () => clearInterval(interval);
  }, [fetchRequest]);

  async function playTheme() {
    await api
      .put(`themes/${theme_id}`, { active: true })
      .then(() => {
        setTheme({ ...theme, active: true });
      })
      .catch(() => {
        toast.error('Já possui um evento ativo.');
      });
  }

  async function stopTheme() {
    await api.put(`themes/${theme_id}`, { active: false });
    setTheme({ ...theme, active: false });
  }

  async function playQuestion(question) {
    await api
      .put(`questions/${question}`, { in_discussion: true })
      .then(() => fetchRequest());
  }

  async function stopQuestion(question) {
    await api
      .put(`questions/${question}`, { in_discussion: false })
      .then(() => fetchRequest());
  }

  async function archiveQuestion(question) {
    await api
      .put(`questions/${question}`, {
        in_discussion: false,
        arquived: true,
      })
      .then(() => fetchRequest());
  }

  return (
    <>
      <Container>
        <aside>
          <h1>{theme.description || ''}</h1>
          <h3>Palestrante: {theme.speaker || ''}</h3>
        </aside>
        {theme && theme.active && (
          <button type="button" onClick={stopTheme} title="Finalizar Palestra">
            <FaRegStopCircle size="30" color="#ff1a00" />
          </button>
        )}
        {theme && !theme.active && (
          <button type="button" onClick={playTheme} title="Iniciar Palestra">
            <FaRegPlayCircle size="30" color="#00cc00" />
          </button>
        )}
      </Container>
      {theme && theme.questions && (
        <Container>
          <ul>
            {theme.questions.map(question => (
              <li key={question.id}>
                <aside>
                  <p>{question.ask}</p>
                  <p>{`${question.name} - ${question.email}`}</p>
                </aside>
                <div>
                  {!question.in_discussion && (
                    <button
                      type="button"
                      title="Exibir Pergunta"
                      onClick={() => playQuestion(question.id)}
                    >
                      <MdScreenShare size="40" color="#00cc00" />
                    </button>
                  )}
                  {question.in_discussion && (
                    <button
                      type="button"
                      title="Remover Pergunta"
                      onClick={() => stopQuestion(question.id)}
                    >
                      <MdStopScreenShare size="40" color="#ff1a00" />
                    </button>
                  )}
                  <button
                    type="button"
                    title="Arquivar Pergunta"
                    onClick={() => archiveQuestion(question.id)}
                  >
                    <MdArchive size="38" color="#ff1a00" />
                  </button>
                  {/* {question.in_discussion} */}
                </div>
              </li>
            ))}
          </ul>
        </Container>
      )}
    </>
  );
}
