import styled from 'styled-components';
import { lighten } from 'polished';

export const Content = styled.div`
  width: 100%;
  height: 100%;
  text-align: center;
  display: flex;
  justify-content: center;
  align-items: center;
`;
export const Container = styled.div`
  width: 300px;
  height: 350px;
  background: #fff;
  border-radius: 7px;

  form {
    display: flex;
    flex-direction: column;
    align-items: center;

    img {
      margin: 20px auto;
    }

    input,
    textarea {
      background: rgba(0, 0, 0, 0.1);
      border: 0;
      border-radius: 4px;
      height: 44px;
      width: 235px;
      padding: 0 15px;
      margin: 0 0 10px;
      &::placeholder {
        color: rgba(0, 0, 0, 0.4);
      }
    }
    textarea {
      resize: none;
      height: 80px;
      padding-top: 10px;
    }
    span {
      color: #312438;
      align-self: flex-start;
      margin: 0 0 10px;
      font-weight: bold;
    }
    button {
      margin: 5px 0 0;
      height: 44px;
      width: 235px;
      background: #312438;
      font-weight: bold;
      color: #fff;
      border: 0;
      border-radius: 4px;
      font-size: 16px;
      transition: background 0.2s;
      &:hover {
        background: ${lighten(0.05, '#312438')};
      }
    }
    a {
      /* color: #fff; */
      margin-top: 15px;
      font-size: 16px;
      opacity: 0.8;
      &:hover {
        opacity: 1;
      }
    }
  }
`;
