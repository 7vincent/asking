import React, { useState, useEffect } from 'react';
// import { Link } from 'react-router-dom';
import { Form, Input, Textarea } from '@rocketseat/unform';
// import { Form, Input, Textarea } from '@unform/web';

import * as Yup from 'yup';
import { toast } from 'react-toastify';

import api from '~/services/api';
import history from '~/services/history';

import Logo from '~/components/Logo';

import { Content, Container } from './styles';

const schema = Yup.object().shape({
  email: Yup.string().email('Insira um e-mail válido'),
  name: Yup.string(),
  ask: Yup.string().required('A pergunta é um campo obrigatório'),
  theme_id: Yup.number(),
});

export default function Asking() {
  const [loading, setLoading] = useState(true);
  const [theme, setTheme] = useState([]);

  useEffect(() => {
    async function loadTheme() {
      await api
        .get(`themes/current`)
        .then(response => {
          setLoading(false);
          setTheme(response.data);
          if (!response.data) {
            toast.error('Nenhum evento ativo no momento.');
            history.push('/');
          }
        })
        .catch(() => {
          toast.error('Nenhum evento ativo no momento.');
          history.push('/');
        });
    }

    loadTheme();
  }, []);

  async function handleSubmit({ ask, name, email, theme_id }, { resetForm }) {
    try {
      setLoading(true);
      await api.post('questions', {
        ask,
        name,
        email,
        theme_id,
      });

      toast.success('Pergunta enviada com sucesso!');
      resetForm();
    } catch (err) {
      toast.error(
        'Ocorreu um erro ao enviar pergunta, verifique os dados informados.'
      );
    }

    setLoading(false);
  }

  return (
    <>
      <Content>
        <Container>
          <Form schema={schema} onSubmit={handleSubmit}>
            <Logo />
            <aside>
              <h4>Tema: {theme && (theme.description || '')}</h4>
              <h5> {theme && (theme.speaker || '')}</h5>
            </aside>
            <Input
              name="theme_id"
              type="hidden"
              value={theme && (theme.id || null)}
            />
            <Input name="name" placeholder="Seu nome" />
            <Input name="email" type="email" placeholder="Seu email" />
            <Textarea name="ask" placeholder="Sua pergunta" />
            <button type="submit">{loading ? 'Enviando...' : 'Enviar'}</button>
            {/* <Link to="/">Voltar</Link> */}
          </Form>
        </Container>
      </Content>
    </>
  );
}
