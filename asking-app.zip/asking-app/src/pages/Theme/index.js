import React, { useState } from 'react';
import { format } from 'date-fns';
import pt from 'date-fns/locale/pt';
import { Link } from 'react-router-dom';
import { Form, Input } from '@rocketseat/unform';
import * as Yup from 'yup';
import { toast } from 'react-toastify';
import api from '~/services/api';

import { Wrapper, Content } from './styles';

const schema = Yup.object().shape({
  description: Yup.string().required('O tema é obrigatório.'),
  speaker: Yup.string().required('O palestrante é obrigatório.'),
  date_event: Yup.string().required('A data do evento é obrigatória.'),
});

export default function Theme() {
  const { search } = window.location;
  const params = new URLSearchParams(search);
  const date = params.get('date');
  const [date_event] = useState(
    format(new Date(date), 'dd/MM/yyyy', { locale: pt })
  );

  async function handleSubmit({ description, speaker, date_event }) {
    try {
      await api.post('themes', {
        description,
        speaker,
        date_event: new Date(date),
      });

      toast.success('Tema cadastrado com sucesso.');
    } catch (err) {
      toast.error('Falha ao cadastrar o novo tema, verifique os dados.');
    }
  }

  return (
    <Wrapper>
      <Content>
        <Form schema={schema} onSubmit={handleSubmit}>
          <Input
            name="date_event"
            placeholder="Data do evento"
            value={date_event || null}
            disabled
          />
          <Input name="description" placeholder="Tema do evento" />
          <Input name="speaker" placeholder="Palestrante do evento" />
          <button type="submit">Enviar</button>
          <Link to="/dashboard">Voltar</Link>
        </Form>
      </Content>
    </Wrapper>
  );
}
