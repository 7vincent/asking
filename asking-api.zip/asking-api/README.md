We used acme.sh for generete ssl cetificates with Let's Encrypt

### Develop enviroment

When you working in develop enviroment rename nginx.conf for prod_nginx.conf and create a new file with name nginx.conf with content below

```apacheconfig
server {
    listen 80;
    server_name 0.0.0.0;

    location / {
        proxy_pass http://express:3333;
        proxy_set_header Host $host;
        proxy_set_header Referer $http_referer;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Host $server_name;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

Or add in your hots the domain api.minhapergunta.com.br to 127.0.0.1 
