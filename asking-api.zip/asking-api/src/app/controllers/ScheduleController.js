import { startOfDay, endOfDay, parseISO } from 'date-fns';
import { Op } from 'sequelize';
import Theme from '../models/Theme';

class ScheduleController {
  async index(req, res) {
    const { date } = req.query;
    const parsedDate = parseISO(date);

    const themes = await Theme.findAll({
      where: {
        date_event: {
          [Op.between]: [startOfDay(parsedDate), endOfDay(parsedDate)],
        },
      },
      order: ['date_event'],
    });

    return res.json(themes);
  }
}

export default new ScheduleController();
