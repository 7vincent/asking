import * as Yup from 'yup';

import Question from '../models/Question';
import Theme from '../models/Theme';
import Notification from '../schemas/Notification';

class QuestionController {
  async index(req, res) {
    const { page = 1 } = req.body;

    const questions = await Question.findAll({
      where: { theme_id: req.body.theme_id, approved: true, discussed: false },
      limit: 10,
      offset: (page - 1) * 10,
      attributes: ['id', 'ask', 'name', 'approved', 'discussed'],
    });

    return res.json(questions);
  }

  async get(req, res) {
    return res.status(501).json({ error: 'Method not implemented.' });
  }

  async store(req, res) {
    const schema = Yup.object().shape({
      ask: Yup.string().required(),
      name: Yup.string(),
      email: Yup.string().email(),
      theme_id: Yup.number().required(),
    });

    if (!(await schema.isValid(req.body))) {
      return res.status(400).json({ error: 'Validation fails.' });
    }

    const { theme_id } = req.body;

    console.log('body:', req.body);

    const theme = await Theme.findByPk(theme_id);

    if (!theme) {
      return res.status(401).json({ error: 'Theme does not exist.' });
    }

    const question = await Question.create(req.body);

    return res.json(question);
  }

  async update(req, res) {
    const schema = Yup.object().shape({
      in_discussion: Yup.boolean(),
      arquived: Yup.boolean(),
    });

    if (!(await schema.isValid(req.body))) {
      return res.status(400).json({ error: 'Validation fails.' });
    }

    const questionExists = await Question.findByPk(req.params.id);

    if (!questionExists) {
      return res.status(400).json({ error: 'Question does not exists.' });
    }

    if (req.body.arquived) {
      await questionExists.update({ in_discussion: false, arquived: true });

      return res.json(questionExists);
    }

    const questionInDiscussion = await Question.findOne({
      where: { in_discussion: true },
    });

    if (
      req.body.in_discussion &&
      questionInDiscussion &&
      !questionInDiscussion.equals(questionExists)
    ) {
      await questionInDiscussion.update({ in_discussion: false });
    }

    const question = await questionExists.update(req.body);

    return res.json(question);
  }

  async delete(req, res) {
    return res.status(501).json({ error: 'Method not implemented.' });
  }
}

export default new QuestionController();
