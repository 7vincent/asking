import Question from '../models/Question';
import Theme from '../models/Theme';

class QuestionDiscussionController {
  async index(req, res) {
    const question = await Question.findOne({
      where: { in_discussion: true },
      include: {
        model: Theme,
        as: 'theme',
        attributes: ['speaker'],
        where: { active: true },
      },
    });

    return res.json(question);
  }
}

export default new QuestionDiscussionController();
