import Question from '../models/Question';
import Theme from '../models/Theme';

class UnarquivedQuestionsController {
  async index(req, res) {
    const { id } = req.params;

    const questions = await Theme.findOne({
      where: { id },
      attributes: ['description', 'speaker', 'active'],
      include: [
        {
          model: Question,
          as: 'questions',
          attributes: [
            'id',
            'ask',
            'name',
            'email',
            'in_discussion',
            'arquived',
          ],
          where: { arquived: false },
          required: false,
        },
      ],
    });

    return res.json(questions);
  }
}

export default new UnarquivedQuestionsController();
