import * as Yup from 'yup';

import Theme from '../models/Theme';
import User from '../models/User';

class ThemeController {
  async currentDiscussion(req, res) {
    const theme = await Theme.findOne({
      where: { active: true },
    });

    return res.json(theme);
  }

  async index(req, res) {
    const { page = 1 } = req.query;

    const themes = await Theme.findAll({
      order: ['date_event'],
      limit: 10,
      offset: (page - 1) * 10,
      attributes: ['id', 'description', 'speaker', 'data_event'],
      include: [
        {
          model: User,
          as: 'user',
          attributes: ['id', 'name', 'email'],
        },
      ],
    });

    return res.json(themes);
  }

  async get(req, res) {
    const theme = await Theme.findByPk(req.params.id, {
      include: [
        {
          model: User,
          as: 'user',
          attributes: ['id', 'name', 'email'],
        },
      ],
    });

    if (!theme) {
      return res.status(401).json({ error: 'Theme does not exist.' });
    }

    return res.json(theme);
  }

  async store(req, res) {
    const schema = Yup.object().shape({
      description: Yup.string().required(),
      speaker: Yup.string().required(),
      date_event: Yup.string().required(),
    });

    if (!(await schema.isValid(req.body))) {
      return res.status(400).json({ error: 'Validation fails.' });
    }

    const { description, speaker, date_event } = req.body;

    const theme = Theme.create({
      user_id: req.userId,
      description,
      speaker,
      date_event,
    });

    return res.json(theme);
  }

  async update(req, res) {
    const schema = Yup.object().shape({
      description: Yup.string(),
      speaker: Yup.string(),
      data_event: Yup.date(),
      active: Yup.boolean(),
    });

    if (!(await schema.isValid(req.body))) {
      return res.status(400).json({ error: 'Validation fails.' });
    }

    const themeExists = await Theme.findByPk(req.params.id);

    if (!themeExists) {
      return res.status(401).json({ error: 'Theme not found.' });
    }

    const activatedTheme = await Theme.findOne({ where: { active: true } });

    if (activatedTheme && !activatedTheme.equals(themeExists)) {
      return res.status(401).json({ error: 'Theme cant activated.' });
    }

    const theme = themeExists.update(req.body);

    return res.json(theme);
  }

  async delete(req, res) {
    const theme = await Theme.findByPk(req.params.id);

    if (!theme) {
      return res.status(401).json({ error: 'Theme not found.' });
    }

    if (theme.user_id !== req.userId) {
      return res.status(401).json({ error: 'You cannot delete this theme.' });
    }

    await Theme.destroy({ where: { id: req.params.id } });

    return res.status(204);
  }
}

export default new ThemeController();
