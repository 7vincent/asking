import Sequelize, { Model } from 'sequelize';

class Question extends Model {
  static init(sequelize) {
    super.init(
      {
        ask: Sequelize.STRING,
        name: Sequelize.STRING,
        email: Sequelize.STRING,
        in_discussion: Sequelize.BOOLEAN,
        arquived: Sequelize.BOOLEAN,
      },
      {
        sequelize,
      }
    );

    return this;
  }

  static associate(models) {
    this.belongsTo(models.Theme, { foreignKey: 'theme_id', as: 'theme' });
  }
}

export default Question;
