import Sequelize, { Model } from 'sequelize';

class Theme extends Model {
  static init(sequelize) {
    super.init(
      {
        description: Sequelize.STRING,
        speaker: Sequelize.STRING,
        date_event: Sequelize.DATE,
        active: Sequelize.BOOLEAN,
      },
      {
        sequelize,
      }
    );

    return this;
  }

  static associate(models) {
    this.belongsTo(models.User, { foreignKey: 'user_id', as: 'user' });
    this.hasMany(models.Question, { foreignKey: 'theme_id', as: 'questions' });
  }

  checkFinished() {
    return this.finished;
  }
}

export default Theme;
