module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.addColumn('themes', 'active', {
      type: Sequelize.BOOLEAN,
      defaultValue: false,
      allowNull: false,
    });
  },

  down: queryInterface => {
    return queryInterface.removeColumn('themes', 'active');
  },
};
