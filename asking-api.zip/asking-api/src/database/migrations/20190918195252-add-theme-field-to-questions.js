module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.addColumn('themes', 'date_event', {
      type: Sequelize.DATE,
      allowNull: false,
    });
  },

  down: queryInterface => {
    return queryInterface.removeColumn('themes', 'date_event');
  },
};
