module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.addColumn('questions', 'theme_id', {
      type: Sequelize.INTEGER,
      references: { model: 'themes', key: 'id' },
      onUpdate: 'CASCADE',
      onDelete: 'SET NULL',
      allowNull: true,
    });
  },

  down: queryInterface => {
    return queryInterface.removeColumn('questions', 'theme_id');
  },
};
