import { Router } from 'express';
import multer from 'multer';
import multerConfig from './config/multer';

import UserController from './app/controllers/UserController';
import SessionController from './app/controllers/SessionController';

import FileController from './app/controllers/FileController';
import NotificationController from './app/controllers/NotificationController';
import QuestionController from './app/controllers/QuestionController';
import ThemeController from './app/controllers/ThemeController';
import ScheduleController from './app/controllers/ScheduleController';
import UnarquivedQuestionsController from './app/controllers/UnarquivedQuestionsController';
import QuestionDiscussionController from './app/controllers/QuestionDiscussionController';

import authMiddleware from './app/middlewares/auth';

const routes = new Router();
const upload = multer(multerConfig);

routes.post('/users', UserController.store);
routes.post('/sessions', SessionController.store);
routes.post('/questions', QuestionController.store);
routes.get('/themes/current', ThemeController.currentDiscussion);
routes.get('/question-discussion', QuestionDiscussionController.index);

routes.use(authMiddleware);

routes.put('/users', UserController.update);

// Themes
routes.get('/themes/:id', ThemeController.get);
routes.post('/themes', ThemeController.store);
routes.put('/themes/:id', ThemeController.update);
routes.delete('/themes/:id', ThemeController.delete);

routes.get('/schedule', ScheduleController.index);

// Question
routes.get('/questions', QuestionController.index);
routes.get(
  '/unarquived-questions/theme/:id',
  UnarquivedQuestionsController.index
);
routes.put('/questions/:id', QuestionController.update);

// Notifications
routes.get('/notifications', NotificationController.index);
routes.put('/notifications/:id', NotificationController.update);

// Upload files
routes.post('/files', upload.single('file'), FileController.store);

export default routes;
