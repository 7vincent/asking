export default {
  secret: 'dbd014085aced4c3064c80a6812936a4',
  expiresIn: '7d',
};
